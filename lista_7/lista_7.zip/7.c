/*
Exercicio 7 - Faça um procedimento que preencha 2 matrizes, A 4 x 6 e B 4 x 6. Faça uma função para 
cada uma das situações a seguir, que recebe duas matrizes preenchidas, calcula e retorna as 
matrizes indicadas
Autor: Leon Júnio Martins Ferreira
Data: 11/11/2021
*/
#include <stdio.h>
#include <stdlib.h>
#define MAX_LN 4
#define MAX_CL 6

void preencherMatriz(int matrizA[MAX_LN][MAX_CL], int matrizB[MAX_LN][MAX_CL])
{
    printf("Preenchendo a matriz A \n");
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            printf("Digite o numero para ocupar a posicao [%d][%d] da matriz A \n", i, j);
            scanf("%d%*c", &matrizA[i][j]);
        }
    }
    printf("Preenchendo a matriz B \n");
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            printf("Digite o numero para ocupar a posicao [%d][%d] da matriz B \n", i, j);
            scanf("%d%*c", &matrizB[i][j]);
        }
    }
    exibirMatriz(matrizA);
    exibirMatriz(matrizB);
}

void exibirMatriz(int matriz[MAX_LN][MAX_CL])
{
    printf("MATRIZ GERADA \n");
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            printf("[%d]", matriz[i][j]);
        }
        printf("\n");
    }
}

int **somaMatrizes(int matrizA[MAX_LN][MAX_CL], int matrizB[MAX_LN][MAX_CL])
{
    int **matrizS = (int **)malloc((sizeof(int) * (MAX_LN * MAX_CL)));
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            matrizS[i][j] = matrizA[i][j] + matrizB[i][j];
        }
    }
    return matrizS;
}

int **subMatrizes(int matrizA[MAX_LN][MAX_CL], int matrizB[MAX_LN][MAX_CL])
{
    int **matrizD = (int **)calloc((sizeof(int) * (MAX_LN * MAX_CL)));
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            matrizD[i][j] = matrizA[i][j] - matrizB[i][j];
        }
    }
    return matrizD;
}

int main(void)
{
    int matrizA[MAX_LN][MAX_CL];
    int matrizB[MAX_LN][MAX_CL];
    int **matrizS = (int **)malloc((sizeof(int) * (MAX_LN * MAX_CL)));
    int **matrizD = (int **)malloc((sizeof(int) * (MAX_LN * MAX_CL)));
    preencherMatriz(matrizA, matrizB);
    printf("MATRIZ RESULTANTE DA SOMA ENTRE A E B: \n");
    matrizS = somaMatrizes(matrizA, matrizB);
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            printf("[%d]", matrizS[i][j]);
        }
        printf("\n");
    }
    printf("MATRIZ RESULTANTE DA SUBTRACAO ENTRE A E B: \n");
    free(matrizS);
    matrizD = subMatrizes(matrizA, matrizB);
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            printf("[%d]", matrizD[i][j]);
        }
        printf("\n");
    }
    free(matrizD);
    printf("FIM DO PROGRAMA \n");
    return 0;
}