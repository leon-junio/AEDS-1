/*
Exercicio 8 - Escrever um procedimento que preenche uma matriz M(10,10) e a escreve. Faça outros 
procedimentos que recebam uma matriz preenchida, realize as trocas indicadas a seguir 
(um procedimento para cada uma delas) e exiba a matriz resultante da troca
Autor: Leon Júnio Martins Ferreira
Data: 11/11/2021
*/
#include <stdio.h>
#define MAX_LN 10
#define MAX_CL 10

void preencherMatriz(int matriz[MAX_LN][MAX_CL])
{
    printf("Preenchendo a matriz \n");
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            printf("Digite o numero para ocupar a posicao [%d][%d] da matriz \n", i, j);
            scanf("%d%*c", &matriz[i][j]);
        }
    }

    printf("MATRIZ GERADA \n");
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            printf("[%d]", matriz[i][j]);
        }
        printf("\n");
    }
}

void exibirMatriz(int matriz[MAX_LN][MAX_CL])
{
    printf("MATRIZ GERADA \n");
    for (int i = 0; i < MAX_LN; i++)
    {
        for (int j = 0; j < MAX_CL; j++)
        {
            printf("[%d]", matriz[i][j]);
        }
        printf("\n");
    }
}

void troca2to8(int matriz[MAX_LN][MAX_CL])
{
    int aux[MAX_LN];
    for (int i = 0; i < MAX_CL; i++)
    {
        aux[i] = matriz[1][i];
        matriz[1][i] = matriz[7][i];
    }
    for (int i = 0; i < MAX_LN; i++)
    {
        matriz[7][i] = aux[i];
    }
    printf("Trocando a linha 2 com a 8 \n");
    exibirMatriz(matriz);
}

void trocaCol4to10(int matriz[MAX_LN][MAX_CL])
{
    int aux[MAX_CL];
    for (int i = 0; i < MAX_LN; i++)
    {
        aux[i] = matriz[i][3];
        matriz[i][3] = matriz[i][9];
    }
    for (int i = 0; i < MAX_CL; i++)
    {
        matriz[i][9] = aux[i];
    }
    printf("Trocando a coluna 4 com a 10 \n");
    exibirMatriz(matriz);
}

void trocaDiagonais(int matriz[MAX_LN][MAX_CL])
{
    int auxp[MAX_CL], cl = MAX_CL - 1;
    for (int i = 0; i < MAX_CL; i++)
    {
        auxp[i] = matriz[i][i];
        matriz[i][i] = matriz[i][cl];
        cl--;
    }
    cl = MAX_CL - 1;
    for (int i = 0; i < MAX_LN; i++)
    {
        matriz[i][cl] = auxp[i];
        cl--;
    }
    printf("Trocando as diagonais \n");
    exibirMatriz(matriz);
}

void troca5to10(int matriz[MAX_LN][MAX_CL])
{
    int aux[MAX_LN];
    for (int i = 0; i < MAX_CL; i++)
    {
        aux[i] = matriz[4][i];
        matriz[4][i] = matriz[i][9];
    }
    for (int i = 0; i < MAX_LN; i++)
    {
        matriz[i][9] = aux[i];
    }
    printf("Trocando a linha 5 com a coluna 10 \n");
    exibirMatriz(matriz);
}

int main(void)
{
    int matriz[MAX_LN][MAX_CL];
    preencherMatriz(matriz);
    troca2to8(matriz);
    trocaCol4to10(matriz);
    trocaDiagonais(matriz);
    troca5to10(matriz);
    printf("FIM DO PROGRAMA \n");
    return 0;
}